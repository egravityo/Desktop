#include<stdio.h>
int main()
{
	char ch='H';
	printf("%x",ch);
	return 0; 
 } 
