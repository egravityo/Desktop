#include<stdio.h>
int main()
{
	int y=10;
	while(y--);
    printf("y=%d\n",y);
	return 0; 
 } 
